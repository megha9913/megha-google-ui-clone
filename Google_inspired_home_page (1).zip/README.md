# Google UI Clone

This is a Google-inspired UI created using HTML and CSS.

⚠️ Disclaimer:
This project is made only for learning and practice purposes.
It is not affiliated with or endorsed by Google.

## Technologies Used
- HTML
- CSS
- Font Awesome